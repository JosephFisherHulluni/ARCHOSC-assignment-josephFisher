// Keeps track of which image is currently shown
let clicks=0;
let velocity=0;
let speed=5;
// Get references to HTML elements
const switchButton = document.getElementById("switchButton")
const birdImage = document.getElementById("flap");
birdImage.src = "pictures/flap.png";
birdImage.style.scale = "0.8";


onload=() => {
    while(clicks>=1){
        birdImage.style.top = `${velocity}%`;
        velocity = lerp(velocity, speed, 0.5);
        speed = speed + 5;
    }
}
document.addEventListener("keydown", function(event) {
    if (event.key === "a") {
        clicks++;
        speed = speed -10;
    }
});

lerp = (start, end, t) => {
    return start * (1 - t) + end * t;
}